import React from "react";
import "./App.css";
import HomePage from "./Components/HomePage/HomePage";
function App() {
  return (
    <div className="App">
      <HomePage />
      {/* <p className=" bg-black text-3xl font-bold underline">fgdg</p> */}
    </div>
  );
}

export default App;
