// import React from "react";
// import "./Left.css";
// import MenuOpen from "../../assets/MenuOpen.png";
// import CrmDashboard from "../../assets/CRMDASHBOARD.png";
// import Task from "../../assets/Task.png";
// import Drive from "../../assets/Drive.png";
// import Board from "../../assets/Boards.png";
// import Updates from "../../assets/updates.png";
// import Analytics from "../../assets/Analytics.png";
// import Setting from "../../assets/Settings.png";
// import Two from "../../assets/Two.png";
// import UpperArrow from "../../assets/UpperArrow.png";
// import Four from "../../assets/Four.png";
// import FourThreeFive from "../../assets/FourThreeFive.png";
// import Five from "../../assets/Five.png";

// function Left() {
//   return (
//     <div className="left_component">
//       <div className="Head">
//         <h3>
//           <strong>Dashboard</strong>
//         </h3>
//         <div className="left_component_icon">
//           <img src={MenuOpen} alt="" />
//         </div>
//       </div>
//       <div>
//         <div className="left_component_content">
//           <div className="sub_heading_left">
//             <p>DASHBOARD</p>
//             <img className="img__name" src={UpperArrow} alt="." />
//           </div>

//           <div className="left_side_content">
//             <div className="list_list">
//               <div className="list_sub">
//                 <img src={CrmDashboard} alt="." />
//                 <p className="list_name">CDRM Dashboard</p>
//               </div>
//               <div className="img_list">
//                 <img src={Two} alt="." />
//               </div>
//             </div>

//             <div className="list_list">
//               <img src={Task} alt="." />
//               <p className="list_name">Task</p>
//               <img src={Four} alt="." />
//             </div>
//             <div className="list_list">
//               <img src={Drive} alt="." />
//               <p className="list_name">Drive Files</p>
//               <img src={FourThreeFive} alt="." />
//             </div>
//             <div className="list_list">
//               <img src={Board} alt="." />
//               <p className="list_name">Boards</p>
//               <img src={Five} alt="." />
//             </div>
//             <div className="list_list">
//               <img src={Updates} alt="." />
//               <p className="list_name">Updates</p>
//             </div>
//             <div className="list_list">
//               <img src={Analytics} alt="." />
//               <p className="list_name">Analytics</p>
//               <img src={Two} alt="." />
//             </div>
//             <div className="list_list">
//               <img src={Setting} alt="." />
//               <p className="list_name">Setting</p>
//               <img src={Two} alt="." />
//             </div>
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// }

// export default Left;

import React from "react";
import "./Left.css";
import MenuOpen from "../../assets/MenuOpen.png";
import CrmDashboard from "../../assets/CRMDASHBOARD.png";
import Task from "../../assets/Task.png";
import Drive from "../../assets/Drive.png";
import Board from "../../assets/Boards.png";
import Updates from "../../assets/updates.png";
import Analytics from "../../assets/Analytics.png";
import Setting from "../../assets/Settings.png";
import Two from "../../assets/Two.png";
import UpperArrow from "../../assets/UpperArrow.png";
import Four from "../../assets/Four.png";
import FourThreeFive from "../../assets/FourThreeFive.png";
import Five from "../../assets/Five.png";

function Left() {
  return (
    <div className="left_component">
      <div className="Head">
        <h3>
          <strong>Dashboards</strong>
        </h3>
        <div className="left_component_icon">
          <img src={MenuOpen} alt="Menu Icon" />
        </div>
      </div>
      <div className="left_component_content">
        <div className="sub_heading_left">
          <p>DASHBOARDS</p>
          <img className="img__name" src={UpperArrow} alt="Arrow Icon" />
        </div>
        <div className="left_side_content">
          <div className="list_list">
            <div className="list_sub">
              <img src={CrmDashboard} alt="CRM Dashboard Icon" />
              <p className="list_name">CRM Dashboard</p>
            </div>
            <div className="img_list">
              <img src={Two} alt="2" />
            </div>
          </div>
          <div className="list_list">
            <div className="list_sub">
              <img src={Task} alt="Task Icon" />
              <p className="list_name">Tasks</p>
            </div>
            <div className="img_list">
              <img src={Four} alt="4" />
            </div>
          </div>
          <div className="list_list">
            <div className="list_sub">
              <img src={Drive} alt="Drive Files Icon" />
              <p className="list_name">Drive Files</p>
            </div>
            <div className="img_list">
              <img src={FourThreeFive} alt="435" />
            </div>
          </div>
          <div className="list_list">
            <div className="list_sub">
              <img src={Board} alt="Boards Icon" />
              <p className="list_name">Boards</p>
            </div>
            <div className="img_list">
              <img src={Five} alt="5" />
            </div>
          </div>
          <div className="list_list">
            <div className="list_sub">
              <img src={Updates} alt="Updates Icon" />
              <p className="list_name">Updates</p>
            </div>
          </div>
          <div className="list_list">
            <div className="list_sub">
              <img src={Analytics} alt="Analytics Icon" />
              <p className="list_name">Analytics</p>
            </div>
            <div className="img_list">
              <img src={Two} alt="2" />
            </div>
          </div>
          <div className="list_list">
            <div className="list_sub">
              <img src={Setting} alt="Settings Icon" />
              <p className="list_name">Settings</p>
            </div>
            <div className="img_list">
              <img src={Two} alt="2" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Left;
