import React from "react";
import "./RightComponent.css";
function RightComponent() {
  return <div className="right_component">right</div>;
}

export default RightComponent;
